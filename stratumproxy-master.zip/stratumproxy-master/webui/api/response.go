package api

type ResponseAPI struct {
	Result bool
	Msg    string
}
