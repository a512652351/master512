package config

var ProjectName = "StratumProxy"

var GitTag string
var BuildTime string
